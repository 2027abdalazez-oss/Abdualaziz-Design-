
import http from "node:http";

const PORT = process.env.PORT || 3000;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || "gpt-5.6-luna";

if (!OPENAI_API_KEY) {
  console.error("Missing OPENAI_API_KEY environment variable.");
  process.exit(1);
}

function send(res, status, data) {
  res.writeHead(status, {"Content-Type":"application/json; charset=utf-8"});
  res.end(JSON.stringify(data));
}

const systemPrompt = `
You are Abdelaziz AI Architecture Studio, an architectural design critic.
Analyze uploaded architectural drawings/renderings as a design assistant, not as a licensed engineer.
Return a clear report in the same language as the user's project text (Arabic or English).
Focus on:
1. Design concept and composition
2. Functional zoning and adjacency
3. Circulation and entrances
4. Daylight, orientation and ventilation (only what can reasonably be inferred)
5. Accessibility and safety observations (do not claim code compliance without jurisdiction/code data)
6. Facade and material/composition observations
7. Strengths
8. Problems / risks
9. Specific improvement suggestions
10. A cautious overall score from 0-100 with reasons.
Clearly state uncertainty where the image does not provide enough information.
`;

async function analyze(payload) {
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${OPENAI_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: MODEL,
      input: [{
        role: "user",
        content: [
          {
            type: "input_text",
            text: `${systemPrompt}\nProject name: ${payload.projectName}\nProject type: ${payload.projectType}`
          },
          {
            type: "input_image",
            image_url: payload.imageDataUrl,
            detail: "high"
          }
        ]
      }]
    })
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data?.error?.message || JSON.stringify(data));
  }
  return data.output_text || "";
}

const server = http.createServer(async (req, res) => {
  if (req.method === "GET" && req.url === "/health") {
    return send(res, 200, {ok:true, model:MODEL});
  }
  if (req.method !== "POST" || req.url !== "/analyze") {
    return send(res, 404, {error:"Not found"});
  }

  let body = "";
  req.on("data", chunk => {
    body += chunk;
    if (body.length > 20 * 1024 * 1024) req.destroy();
  });
  req.on("end", async () => {
    try {
      const payload = JSON.parse(body);
      if (!payload.imageDataUrl) return send(res, 400, {error:"imageDataUrl is required"});
      const analysis = await analyze(payload);
      send(res, 200, {analysis});
    } catch (e) {
      send(res, 500, {error:e.message || "AI request failed"});
    }
  });
});

server.listen(PORT, () => console.log(`AI backend listening on http://localhost:${PORT}`));
