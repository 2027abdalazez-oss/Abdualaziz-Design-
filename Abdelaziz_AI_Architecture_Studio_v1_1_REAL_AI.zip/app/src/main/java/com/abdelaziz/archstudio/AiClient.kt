
package com.abdelaziz.archstudio

import android.content.Context
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class AiClient(private val context: Context) {
    private val http = OkHttpClient()

    // For emulator use http://10.0.2.2:3000
    // For a real phone, replace with the LAN IP of your backend, e.g. http://192.168.1.20:3000
    private val baseUrl = BuildConfig.AI_BASE_URL

    suspend fun analyze(imageUri: Uri?, projectName: String, projectType: String): String =
        withContext(Dispatchers.IO) {
            if (imageUri == null) {
                throw IllegalArgumentException("Please choose an image first.")
            }

            val bytes = context.contentResolver.openInputStream(imageUri)?.use { it.readBytes() }
                ?: throw IllegalStateException("Could not read image.")

            val mime = context.contentResolver.getType(imageUri) ?: "image/jpeg"
            val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)

            val bodyJson = JSONObject()
                .put("projectName", projectName)
                .put("projectType", projectType)
                .put("imageDataUrl", "data:$mime;base64,$b64")

            val request = Request.Builder()
                .url("$baseUrl/analyze")
                .post(bodyJson.toString().toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IllegalStateException("AI server error ${response.code}: $text")
                }
                JSONObject(text).optString("analysis", text)
            }
        }
}
