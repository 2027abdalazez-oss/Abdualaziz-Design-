package com.abdelaziz.archstudio

import android.net.Uri
import android.os.Bundle
import android.content.Context
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.navigation.compose.*
import coil.compose.AsyncImage

data class Project(
    val id: Int,
    val name: String,
    val type: String,
    val image: Uri? = null,
    val score: Int? = null
)

data class Analysis(
    val score: Int,
    val strengths: List<String>,
    val notes: List<String>,
    val next: List<String>
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ArchitectureStudioApp() }
    }
}

@Composable
fun ArchitectureStudioApp() {
    var arabic by remember { mutableStateOf(true) }
    var projects by remember { mutableStateOf(listOf<Project>()) }
    var selected by remember { mutableStateOf<Project?>(null) }
    var screen by remember { mutableStateOf("home") }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF1E293B),
            secondary = Color(0xFF64748B),
            background = Color(0xFFF8FAFC),
            surface = Color.White
        )
    ) {
        when (screen) {
            "home" -> HomeScreen(
                arabic, { arabic = !arabic },
                projects,
                onNew = { screen = "new" },
                onOpen = { selected = it; screen = "project" }
            )
            "new" -> NewProjectScreen(
                arabic,
                onBack = { screen = "home" },
                onCreate = { name, type, uri ->
                    val p = Project((projects.maxOfOrNull { it.id } ?: 0) + 1, name, type, uri)
                    projects = projects + p
                    selected = p
                    screen = "project"
                }
            )
            "project" -> selected?.let { p ->
                ProjectScreen(
                    arabic, p, LocalContext.current,
                    onBack = { screen = "home" },
                    onAnalyze = { screen = "analysis" }
                )
            }
            "analysis" -> selected?.let { p ->
                AnalysisScreen(arabic, p, onBack = { screen = "project" })
            }
        }
    }
}

@Composable
fun AppHeader(arabic: Boolean, onLang: () -> Unit, onBack: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = null)
            }
        }
        Column(Modifier.weight(1f)) {
            Text(
                "Abdelaziz AI Architecture Studio",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                if (arabic) "استديو العمارة الذكي" else "Smart Architecture Studio",
                color = MaterialTheme.colorScheme.secondary,
                fontSize = 12.sp
            )
        }
        TextButton(onClick = onLang) {
            Text(if (arabic) "EN" else "عربي")
        }
    }
}

@Composable
fun HomeScreen(
    arabic: Boolean,
    onLang: () -> Unit,
    projects: List<Project>,
    onNew: () -> Unit,
    onOpen: (Project) -> Unit
) {
    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onNew) {
                Icon(Icons.Default.Add, contentDescription = null)
            }
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            AppHeader(arabic, onLang)
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text(
                    if (arabic) "حلّل أفكارك المعمارية بالذكاء الاصطناعي" else
                        "Analyze your architectural ideas with AI",
                    fontSize = 27.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    if (arabic) "ارفع مخططًا أو رندرًا وابدأ جلسة نقد معماري." else
                        "Upload a plan or render and start an architecture critique.",
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = onNew,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (arabic) "مشروع جديد" else "New Project")
                }
                Spacer(Modifier.height(28.dp))
                Text(
                    if (arabic) "مشاريعي" else "My Projects",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
                Spacer(Modifier.height(10.dp))
                if (projects.isEmpty()) {
                    EmptyCard(arabic, onNew)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(projects) { p -> ProjectCard(arabic, p, onOpen) }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyCard(arabic: Boolean, onNew: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onNew),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(30.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.Architecture, null, Modifier.size(48.dp))
            Spacer(Modifier.height(10.dp))
            Text(if (arabic) "لا توجد مشاريع بعد" else "No projects yet", fontWeight = FontWeight.Bold)
            Text(
                if (arabic) "ابدأ أول مشروع معماري لك." else "Start your first architecture project.",
                color = MaterialTheme.colorScheme.secondary
            )
        }
    }
}

@Composable
fun ProjectCard(arabic: Boolean, p: Project, onOpen: (Project) -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onOpen(p) }, RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            if (p.image != null) {
                AsyncImage(
                    model = p.image,
                    contentDescription = null,
                    modifier = Modifier.size(70.dp).clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    Modifier.size(70.dp).clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Architecture, null) }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(p.name, fontWeight = FontWeight.Bold)
                Text(p.type, color = MaterialTheme.colorScheme.secondary)
                if (p.score != null) Text("${if (arabic) "التقييم" else "Score"}: ${p.score}/100")
            }
            Icon(Icons.Default.ChevronRight, null)
        }
    }
}

@Composable
fun NewProjectScreen(
    arabic: Boolean,
    onBack: () -> Unit,
    onCreate: (String, String, Uri?) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        imageUri = it
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppHeader(arabic, {}, onBack)
        Column(Modifier.padding(horizontal = 20.dp)) {
            Text(
                if (arabic) "إنشاء مشروع جديد" else "Create New Project",
                fontSize = 28.sp, fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text(if (arabic) "اسم المشروع" else "Project name") },
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = type, onValueChange = { type = it },
                label = { Text(if (arabic) "نوع المشروع" else "Project type") },
                placeholder = { Text(if (arabic) "سكني، إداري، ثقافي..." else "Residential, office, cultural...") },
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            Spacer(Modifier.height(18.dp))
            OutlinedButton(
                onClick = { launcher.launch("image/*") },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(Icons.Default.Image, null)
                Spacer(Modifier.width(8.dp))
                Text(if (arabic) "اختيار مخطط / رندر" else "Choose Plan / Render")
            }
            imageUri?.let {
                Spacer(Modifier.height(14.dp))
                AsyncImage(
                    model = it, contentDescription = null,
                    modifier = Modifier.fillMaxWidth().height(230.dp)
                        .clip(RoundedCornerShape(16.dp)),
                    contentScale = ContentScale.Fit
                )
            }
            Spacer(Modifier.height(24.dp))
            Button(
                enabled = name.isNotBlank(),
                onClick = { onCreate(name, if (type.isBlank()) "Architecture Project" else type, imageUri) },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(if (arabic) "إنشاء المشروع" else "Create Project")
            }
            Spacer(Modifier.height(40.dp))
        }
    }
}


@Composable
fun ProjectScreen(
    arabic: Boolean,
    p: Project,
    context: Context,
    onBack: () -> Unit,
    onAnalyze: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(false) }
    var aiResult by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppHeader(arabic, {}, onBack)
        Column(Modifier.padding(horizontal = 20.dp)) {
            Text(p.name, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(p.type, color = MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.height(18.dp))

            if (p.image != null) {
                AsyncImage(
                    model = p.image, contentDescription = null,
                    modifier = Modifier.fillMaxWidth().height(300.dp)
                        .clip(RoundedCornerShape(18.dp)),
                    contentScale = ContentScale.Fit
                )
            } else {
                Card(Modifier.fillMaxWidth().height(220.dp), RoundedCornerShape(18.dp)) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Image, null, Modifier.size(54.dp))
                            Text(if (arabic) "لم يتم رفع صورة" else "No image uploaded")
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Button(
                enabled = !loading && p.image != null,
                onClick = {
                    loading = true
                    error = null
                    aiResult = null
                    scope.launch {
                        try {
                            aiResult = AiClient(context).analyze(p.image, p.name, p.type)
                        } catch (e: Exception) {
                            error = e.message ?: "Unknown error"
                        } finally {
                            loading = false
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                if (loading) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(if (arabic) "جاري التحليل..." else "Analyzing...")
                } else {
                    Icon(Icons.Default.AutoAwesome, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (arabic) "حلّل المشروع بالـAI الحقيقي" else "Analyze with Real AI")
                }
            }

            if (p.image == null) {
                Spacer(Modifier.height(8.dp))
                Text(
                    if (arabic) "ارفع صورة أولًا لتفعيل التحليل." else "Upload an image first.",
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            error?.let {
                Spacer(Modifier.height(12.dp))
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Text(it, Modifier.padding(14.dp))
                }
            }

            aiResult?.let {
                Spacer(Modifier.height(18.dp))
                Card(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(
                            if (arabic) "نتيجة تحليل AI" else "AI Analysis Result",
                            fontSize = 20.sp, fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(it, lineHeight = 22.sp)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                onClick = onAnalyze,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(Icons.Default.Assessment, null)
                Spacer(Modifier.width(8.dp))
                Text(if (arabic) "عرض التقرير التجريبي" else "View Demo Report")
            }
        }
    }
}

fun mockAnalysis(): Analysis = Analysis(
    82,
    listOf(
        "وضوح الفكرة العامة للمشروع.",
        "التوزيع الوظيفي يبدو متماسكًا مبدئيًا.",
        "وجود فرصة جيدة لتطوير العلاقة بين الفراغات."
    ),
    listOf(
        "راجع تسلسل الحركة من المدخل إلى الفراغات الرئيسية.",
        "تحقق من الإضاءة الطبيعية في الفراغات العميقة.",
        "راجع أبعاد الممرات والأبواب وفق الكود المعتمد.",
        "وازن نسب الفتحات في الواجهة مع اتجاه الشمس."
    ),
    listOf(
        "ارسم Diagram للحركة قبل تعديل المخطط.",
        "قارن بديلين للتوزيع الوظيفي.",
        "اختبر الظلال والإضاءة في أوقات مختلفة."
    )
)

@Composable
fun AnalysisScreen(arabic: Boolean, p: Project, onBack: () -> Unit) {
    val a = remember { mockAnalysis() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppHeader(arabic, {}, onBack)
        Column(Modifier.padding(horizontal = 20.dp)) {
            Text(
                if (arabic) "تقرير التحليل المعماري" else "Architecture Analysis Report",
                fontSize = 26.sp, fontWeight = FontWeight.Bold
            )
            Text(p.name, color = MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.height(18.dp))
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (arabic) "التقييم المبدئي" else "Initial Score", fontWeight = FontWeight.Bold)
                    Text("${a.score}/100", fontSize = 42.sp, fontWeight = FontWeight.Bold)
                    Text(if (arabic) "هذا تقييم تجريبي للواجهة وليس حكمًا هندسيًا." else
                        "This is a demo score, not an engineering judgment.",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                }
            }
            Spacer(Modifier.height(18.dp))
            Section(
                if (arabic) "نقاط القوة" else "Strengths",
                a.strengths, Icons.Default.CheckCircle
            )
            Section(
                if (arabic) "ملاحظات تحتاج مراجعة" else "Review Notes",
                a.notes, Icons.Default.Warning
            )
            Section(
                if (arabic) "الخطوات المقترحة" else "Next Steps",
                a.next, Icons.Default.Lightbulb
            )
            Spacer(Modifier.height(30.dp))
        }
    }
}

@Composable
fun Section(title: String, items: List<String>, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    items.forEach { item ->
        Card(Modifier.fillMaxWidth().padding(bottom = 8.dp), RoundedCornerShape(14.dp)) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                Icon(icon, null, Modifier.size(22.dp))
                Spacer(Modifier.width(10.dp))
                Text(item, lineHeight = 21.sp)
            }
        }
    }
}
