# Abdelaziz AI Architecture Studio

نسخة أولى (MVP) لتطبيق Android ثنائي اللغة: عربي / English.

## ما الذي تعمل عليه النسخة؟
- إنشاء مشروع معماري.
- حفظ اسم المشروع ونوعه.
- اختيار صورة من الهاتف.
- عرض معاينة الصورة.
- تحليل تجريبي محلي للمشروع (Mock AI) لإثبات واجهة الاستخدام.
- صفحة تقرير تحتوي على التقييم، نقاط القوة، والملاحظات.
- تبديل اللغة عربي / English.

> ملاحظة: تحليل AI الحقيقي غير مفعّل في هذه النسخة. زر التحليل يستخدم بيانات تجريبية محلية حتى تستطيع تجربة التطبيق بدون API Key.
> لاحقًا يمكن ربطه بخادم آمن يستدعي نموذج رؤية/لغة، مع عدم وضع مفتاح API داخل APK.

## المتطلبات
- Android Studio Ladybug أو أحدث.
- JDK 17.
- Android SDK 35.

## تشغيل
1. افتح مجلد المشروع في Android Studio.
2. انتظر Gradle Sync.
3. اختر جهاز Android أو Emulator.
4. Run ▶.

## بناء APK
من Android Studio:
Build > Build Bundle(s) / APK(s) > Build APK(s)

سيظهر APK داخل:
app/build/outputs/apk/debug/app-debug.apk

## الخطوة التالية المقترحة
إضافة Backend آمن لتحليل المخططات والرندرات بالذكاء الاصطناعي، ثم:
- تحليل الحركة والتوزيع.
- تحليل الإضاءة والتهوية.
- تعليم مناطق المشكلة على الصورة.
- محادثة صوتية مع AI.


# تشغيل AI الحقيقي

النسخة 1.1 أضيف إليها Backend منفصل لحماية مفتاح OpenAI.
تطبيق Android لا يحتوي على مفتاح API.

## 1) تجهيز Backend
ثبّت Node.js 20+ ثم:

```bash
cd ai-backend
npm install
```

في Linux/macOS:
```bash
export OPENAI_API_KEY="ضع_مفتاحك_هنا"
export OPENAI_MODEL="gpt-5.6-luna"
npm start
```

في Windows PowerShell:
```powershell
$env:OPENAI_API_KEY="ضع_مفتاحك_هنا"
$env:OPENAI_MODEL="gpt-5.6-luna"
npm start
```

## 2) تشغيل التطبيق
- Android Emulator: الإعداد الافتراضي هو `http://10.0.2.2:3000`.
- هاتف حقيقي: غيّر `AI_BASE_URL` في `app/build.gradle.kts` إلى عنوان جهاز الكمبيوتر داخل الشبكة المحلية، مثل `http://192.168.1.20:3000`.
- للإصدار المنشور استخدم HTTPS وخادمًا عامًا، وليس HTTP المحلي.

## 3) ماذا يفعل؟
يرسل التطبيق الصورة كـdata URL إلى الـBackend، والـBackend يرسلها إلى Responses API كـ`input_image` مع تعليمات نقد معماري، ثم يعيد النص للتطبيق.

OpenAI يدعم إدخال الصور في Responses API، بما في ذلك base64 data URLs. راجع وثائق OpenAI الرسمية قبل النشر.
