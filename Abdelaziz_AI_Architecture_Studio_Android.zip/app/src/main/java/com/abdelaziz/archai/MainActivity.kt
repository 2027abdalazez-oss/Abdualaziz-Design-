package com.abdelaziz.archai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

data class Project(val name: String, val type: String, val date: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ArchAIApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArchAIApp() {
    var arabic by remember { mutableStateOf(true) }
    var showNew by remember { mutableStateOf(false) }
    var showAnalysis by remember { mutableStateOf(false) }
    var projects by remember {
        mutableStateOf(listOf(
            Project("مشروع سكني تجريبي", "Residential", "01/09/2026")
        ))
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                if (arabic) "Abdelaziz AI Architecture Studio"
                                else "Abdelaziz AI Architecture Studio",
                                fontSize = 18.sp, fontWeight = FontWeight.Bold
                            )
                            Text(
                                if (arabic) "استديو التحليل المعماري الذكي"
                                else "Smart Architectural Analysis Studio",
                                fontSize = 11.sp
                            )
                        }
                    },
                    actions = {
                        TextButton(onClick = { arabic = !arabic }) {
                            Text(if (arabic) "EN" else "عربي")
                        }
                    }
                )
            },
            floatingActionButton = {
                ExtendedFloatingActionButton(
                    onClick = { showNew = true },
                    icon = { Icon(Icons.Default.Add, null) },
                    text = { Text(if (arabic) "مشروع جديد" else "New Project") }
                )
            }
        ) { pad ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(pad).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card {
                        Column(Modifier.padding(18.dp)) {
                            Text(
                                if (arabic) "حلّل مشروعك بالذكاء الاصطناعي"
                                else "Analyze your project with AI",
                                fontSize = 21.sp, fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                if (arabic)
                                    "أضف مشروعًا ثم استخدم التحليل المعماري للحصول على ملاحظات عن الحركة والتوزيع والإضاءة والواجهة."
                                else
                                    "Add a project and use architectural analysis for circulation, zoning, daylight and facade feedback."
                            )
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = { showAnalysis = true }) {
                                Icon(Icons.Default.AutoAwesome, null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (arabic) "تجربة التحليل" else "Try Analysis")
                            }
                        }
                    }
                }
                item {
                    Text(
                        if (arabic) "مشاريعي" else "My Projects",
                        fontSize = 20.sp, fontWeight = FontWeight.Bold
                    )
                }
                items(projects) { p ->
                    Card {
                        Row(
                            Modifier.fillMaxWidth().padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Architecture, null, Modifier.size(42.dp))
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold)
                                Text("${p.type} • ${p.date}", fontSize = 12.sp)
                            }
                            OutlinedButton(onClick = { showAnalysis = true }) {
                                Text(if (arabic) "تحليل" else "Analyze")
                            }
                        }
                    }
                }
            }
        }

        if (showNew) {
            NewProjectDialog(
                arabic = arabic,
                onDismiss = { showNew = false },
                onCreate = { name, type ->
                    projects = projects + Project(name, type, "01/09/2026")
                    showNew = false
                }
            )
        }

        if (showAnalysis) {
            AnalysisDialog(arabic = arabic, onDismiss = { showAnalysis = false })
        }
    }
}

@Composable
fun NewProjectDialog(
    arabic: Boolean,
    onDismiss: () -> Unit,
    onCreate: (String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card {
            Column(Modifier.padding(20.dp)) {
                Text(
                    if (arabic) "مشروع جديد" else "New Project",
                    fontSize = 21.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    label = { Text(if (arabic) "اسم المشروع" else "Project name") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = type, onValueChange = { type = it },
                    label = { Text(if (arabic) "نوع المشروع" else "Project type") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = onDismiss) { Text(if (arabic) "إلغاء" else "Cancel") }
                    Button(
                        onClick = { if (name.isNotBlank()) onCreate(name, type.ifBlank { "Architecture" }) },
                        enabled = name.isNotBlank()
                    ) { Text(if (arabic) "إنشاء" else "Create") }
                }
            }
        }
    }
}

@Composable
fun AnalysisDialog(arabic: Boolean, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card {
            Column(Modifier.padding(20.dp)) {
                Text(
                    if (arabic) "🤖 التحليل المعماري" else "🤖 Architectural Analysis",
                    fontSize = 21.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(12.dp))
                AnalysisRow(if (arabic) "الحركة والتنقل" else "Circulation", "82/100")
                AnalysisRow(if (arabic) "التوزيع الوظيفي" else "Functional zoning", "78/100")
                AnalysisRow(if (arabic) "الإضاءة الطبيعية" else "Daylight", "74/100")
                AnalysisRow(if (arabic) "الواجهة والتكوين" else "Facade & composition", "86/100")
                AnalysisRow(if (arabic) "الوصول الشامل" else "Accessibility", "70/100")
                Spacer(Modifier.height(10.dp))
                Text(
                    if (arabic)
                        "ملاحظة تجريبية: حسّن وضوح المدخل، وقلّل تقاطع مسارات الخدمة مع مسارات المستخدمين. هذه النسخة تستخدم تحليلًا محليًا تجريبيًا؛ ربط AI الحقيقي يضاف في المرحلة التالية."
                    else
                        "Demo note: improve entrance legibility and reduce intersections between service and user circulation. This build uses local demo analysis; real AI integration is planned for the next stage."
                )
                Spacer(Modifier.height(14.dp))
                Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                    Text(if (arabic) "إغلاق" else "Close")
                }
            }
        }
    }
}

@Composable
fun AnalysisRow(label: String, score: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text(label, Modifier.weight(1f))
        Text(score, fontWeight = FontWeight.Bold)
    }
}
