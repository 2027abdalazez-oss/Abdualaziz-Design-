# Abdelaziz AI Architecture Studio

Android starter project for a bilingual Arabic/English architectural AI studio.

## Features in this first build
- Arabic / English toggle
- Create projects
- Project list
- Demo architectural analysis
- Architecture-focused scoring categories

## Build
Open the project in Android Studio and let Gradle sync.
Then choose:
Build > Build APK(s)

The generated APK is normally under:
app/build/outputs/apk/debug/

## Next stage
The current analysis is intentionally local/demo and does NOT call an AI service.
For a production version, add a secure backend that receives project images/PDFs and calls an AI vision model. Do not place a secret API key directly inside the APK.
